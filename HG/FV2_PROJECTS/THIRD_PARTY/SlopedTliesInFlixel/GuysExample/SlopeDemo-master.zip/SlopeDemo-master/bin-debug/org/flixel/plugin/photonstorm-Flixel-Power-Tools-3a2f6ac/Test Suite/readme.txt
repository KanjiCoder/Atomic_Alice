Flixel Power Tools Test Suite
-----------------------------

Updated 10th October 2011

http://www.photonstorm.com

This FlashDevelop project contains a suite of demos and example code for the Flixel Power Tools.

Load the project into FlashDevelop and run it, or run the SWF in the bin folder.

The code of each of the examples is stored in src/tests.

Look at them for examples of how to use the commands.

There is a "Getting Started Guide" in the Docs folder